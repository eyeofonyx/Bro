# Wii engine integration

This wrapper is distributed under GPL-2.0-or-later. See LICENSE. Engine credits, exact upstream corresponding-source access and version identity are in public/engine/licenses.html and public/engine/dolphin/VERSION.json.

## Engine

The unmodified core and loader are wasm-dolphin v0.1.1, commit 72759cbb512b9a8e3aaaae3b6617bf28a61d3a65. Core SHA-256: 3b2ed6fe35ff1939e24bbe033edba34b9585f4f7b1f457f1e683ed8ddbd005d0. The shipped .wasm is a real upstream Dolphin implementation, not the repository's demonstration core.

The upstream browser host JS is vendored under public/engine/dolphin/src. The only upstream edit adds playerStatus and playerPause requests to upstream-discio-worker.js. Neither binary nor Emscripten JS is modified.

## Capabilities and limitations

- Local File is mounted using upstream Emscripten WORKERFS. No full-image buffer or upload is created by the wrapper.
- Real CPU boot is requested through UpstreamWorkerAdapter.mountGame and BootDisc.
- The software renderer is selected deliberately for Mario Kart Wii (the upstream hardware renderer has in-race viewport problems).
- The upstream worker owns an OffscreenCanvas. Audio is pulled through the upstream AudioController; default muted; a user action enables sound.
- GameCube main stick is supplied through SetInputState; arrows also set the upstream stick mask. A/B, L/R triggers and digital buttons are supplied too. T (or Trick) sets D-pad up, not main-stick up. No Wii Remote support is claimed.
- Pause and status are acknowledged by the real engine. The player labels game video only after BootDisc accepted, core Running, and frame count advancement; this is NOT proof of correct game graphics, a working race or full speed.
- Engine verification separately checks SHA-256 for the loader and core, compiles the actual Wasm, and checks minified exports via the loader mapping. It does not instantiate 1.5 GB or claim game compatibility.
- Core reserves 1.5 GB of shared WebAssembly memory. Runtime checks require secure context, cross-origin isolation, SharedArrayBuffer, Wasm SIMD, workers and OffscreenCanvas transfer.
- The Maypop embed presently does not provide cross-origin isolation. Adding headers inside the app cannot fix a non-isolated ancestor. The wrapper reports this instead of simulating gameplay. The separately built GitHub Pages website attempts an actual service-worker header workaround, limited to top-level standalone pages. See GITHUB-PAGES.md. This is not presented as verified iPad game compatibility.
- No copyrighted game image, BIOS, tickets or keys are bundled or fetched by the wrapper. A real MKWii ISO has not been provided, so full game boot, race input, sound, saves and iOS performance cannot be qualified here.
- Closing the player terminates its worker tree and closes audio. Focus loss releases held buttons; backgrounding an active video session requests pause.

## Reproduce the wrapper

Install the package manager indicated by package.json / pnpm-lock.yaml, run `pnpm install --frozen-lockfile`, then `pnpm build`. The complete published frontend is produced in dist. The upstream core can be rebuilt using its full corresponding-source archive and documented toolchain; see the included provenance records and upstream source link.

## Source download

Refresh public/engine/wrapper-source.tar.gz after modifying integration source. It contains the app sources, configuration/locks, these notes, and modified browser host. The unmodified Dolphin C++ source and core build inputs are supplied in the upstream corresponding-source archive linked from public/engine/licenses.html.
