import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { maypop } from '@basilica-digital/maypop-sdk/vite'

export default defineConfig(({ mode }) => {
 const standalone = mode === 'standalone'
 return {
  base: standalone ? './' : '/',
  plugins: standalone ? [react()] : [react(), maypop()],
  define: { 'import.meta.env.VITE_STANDALONE': JSON.stringify(standalone ? 'true' : 'false') },
  build: { outDir: standalone ? 'dist-pages' : 'dist' },
  server: { hmr: { overlay: false } },
 }
})
