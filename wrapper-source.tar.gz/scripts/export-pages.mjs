import { readdir, readFile, writeFile, mkdir, rm } from 'node:fs/promises'
import { spawnSync } from 'node:child_process'
import { deflateRawSync } from 'node:zlib'
import { resolve } from 'node:path'

const root = resolve(import.meta.dirname, '..')
process.chdir(root)
function run(command, args) {
 const result = spawnSync(command, args, { stdio: 'inherit' })
 if (result.status !== 0) throw new Error(`${command} failed (${result.status})`)
}
// The same corresponding-source download is included in both distributions.
run('tar', ['-czf', 'public/engine/wrapper-source.tar.gz', 'src', 'checks', 'scripts', 'index.html', 'package.json', 'pnpm-lock.yaml', 'tsconfig.json', 'tsconfig.app.json', 'tsconfig.node.json', 'vite.config.ts', 'maypop.toml', '.oxlintrc.json', 'LICENSE', 'README.md', 'ENGINE-INTEGRATION.md', 'GITHUB-PAGES.md', 'public/favicon.svg', 'public/coi-serviceworker.js', 'public/hosting', 'public/engine/licenses.html', 'public/engine/dolphin/src', 'public/engine/dolphin/provenance', 'public/engine/dolphin/VERSION.json', 'public/engine/dolphin/LICENSE', 'public/engine/dolphin/README.md', 'public/engine/dolphin/cores/dolphin/dolphin-core-upstream.js', 'public/engine/dolphin/cores/dolphin/dolphin-core-upstream.build.json'])
run('pnpm', ['build:pages'])
await rm('dist-pages/downloads', { recursive: true, force: true })
await writeFile('dist-pages/.nojekyll', '')
await writeFile('dist-pages/START-HERE.txt', await readFile('GITHUB-PAGES.md'))
await writeFile('dist-pages/LICENSE', await readFile('LICENSE'))

// Small dependency-free standard ZIP writer. Paths are relative and UTF-8; no ZIP64 needed.
const crcTable = Array.from({ length: 256 }, (_, n) => { for (let i = 0; i < 8; i++) n = n & 1 ? 0xedb88320 ^ (n >>> 1) : n >>> 1; return n >>> 0 })
function crc32(data) { let crc = 0xffffffff; for (const byte of data) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8); return (crc ^ 0xffffffff) >>> 0 }
async function files(dir, prefix = '') {
 const result = []
 for (const entry of (await readdir(dir, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
  const name = `${prefix}${entry.name}`
  if (entry.isDirectory()) result.push(...await files(`${dir}/${entry.name}`, `${name}/`))
  else if (entry.isFile()) result.push({ name, data: await readFile(`${dir}/${entry.name}`) })
 }
 return result
}
const entries = await files('dist-pages')
const localParts = [], centralParts = []
let offset = 0
for (const { name, data } of entries) {
 const filename = Buffer.from(name), compressed = deflateRawSync(data), crc = crc32(data)
 const local = Buffer.alloc(30)
 local.writeUInt32LE(0x04034b50); local.writeUInt16LE(20, 4); local.writeUInt16LE(0x800, 6); local.writeUInt16LE(8, 8); local.writeUInt16LE(0x21, 12)
 local.writeUInt32LE(crc, 14); local.writeUInt32LE(compressed.length, 18); local.writeUInt32LE(data.length, 22); local.writeUInt16LE(filename.length, 26)
 localParts.push(local, filename, compressed)
 const central = Buffer.alloc(46)
 central.writeUInt32LE(0x02014b50); central.writeUInt16LE(20, 4); central.writeUInt16LE(20, 6); central.writeUInt16LE(0x800, 8); central.writeUInt16LE(8, 10); central.writeUInt16LE(0x21, 14)
 central.writeUInt32LE(crc, 16); central.writeUInt32LE(compressed.length, 20); central.writeUInt32LE(data.length, 24); central.writeUInt16LE(filename.length, 28); central.writeUInt32LE(offset, 42)
 centralParts.push(central, filename)
 offset += local.length + filename.length + compressed.length
}
const central = Buffer.concat(centralParts), end = Buffer.alloc(22)
end.writeUInt32LE(0x06054b50); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10); end.writeUInt32LE(central.length, 12); end.writeUInt32LE(offset, 16)
await mkdir('public/downloads', { recursive: true })
const archive = Buffer.concat([...localParts, central, end])
await writeFile('public/downloads/github-pages.zip', archive)
console.log(`GitHub Pages export: ${entries.length} files, ${archive.length} bytes. No game or personal data included.`)
