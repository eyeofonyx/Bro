import regression from './wrapper.scenario.mjs'
export default async(args)=>{
 let player
 await regression({...args,open:async(...parameters)=>{player=await args.open(...parameters);return player}})
 const {check}=args,{page}=player,frame=page.frameLocator('iframe#app')
 await frame.getByRole('button',{name:'Setup',exact:true}).click()
 await check('Embedded preview explains the standalone route without registering a memory helper',async()=>{
  await frame.getByRole('heading',{name:'A separate Safari page.',exact:true}).waitFor()
  await frame.getByText('This preview stays embedded',{exact:true}).waitFor()
  const worker=await frame.locator('body').evaluate(()=>navigator.serviceWorker?.controller?.scriptURL||'')
  if(worker.endsWith('coi-serviceworker.js'))throw Error('The memory helper must not take over the embedded app')
 })
 await check('Ready-to-host download is a real ZIP and the upload instructions preserve folders',async()=>{
  const link=frame.getByRole('link',{name:'Download website ZIP'})
  if((await link.getAttribute('download'))===null)throw Error('Missing download behavior')
  const href=await link.evaluate(a=>a.href),result=await page.request.get(href),bytes=await result.body()
  if(!result.ok()||bytes.length<1_000_000||bytes.readUInt32LE(0)!==0x04034b50)throw Error('Missing website ZIP')
  const started=page.waitForEvent('download',{timeout:5000})
  await link.click()
  const download=await started
  if(await download.failure())throw Error('Website download was blocked')
  await frame.getByText(/Uploading the ZIP alone will not work/).waitFor()
  await frame.getByText(/Full game boot, racing and iPad performance remain unverified/).waitFor()
  await frame.getByRole('heading',{name:'A separate Safari page.',exact:true}).scrollIntoViewIfNeeded()
 })
}
