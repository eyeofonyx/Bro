export default async ({open,check,url})=>{
 const {page}=await open('pages',url,{hasTouch:true})
 await check('Standalone website starts from a repository subfolder and enables real shared memory',async()=>{
  await page.getByRole('button',{name:'Setup',exact:true}).waitFor({timeout:20000})
  await page.getByRole('button',{name:'Setup',exact:true}).click()
  await page.getByText('Shared memory ready',{exact:true}).waitFor()
  const state=await page.evaluate(()=>({isolated:crossOriginIsolated,memory:typeof SharedArrayBuffer,worker:navigator.serviceWorker.controller?.scriptURL,marker:location.search,frames:document.querySelectorAll('iframe').length}))
  if(!state.isolated||state.memory!=='function'||!state.worker?.endsWith('/kart/coi-serviceworker.js')||state.marker.includes('memory-check')||state.frames!==0)throw Error(JSON.stringify(state))
  await page.getByText('Browser prerequisites detected.',{exact:true}).waitFor()
  await page.getByRole('heading',{name:'A separate Safari page.',exact:true}).scrollIntoViewIfNeeded()
 })
 await check('Real core loads under the repository path without a Maypop session',async()=>{
  await page.getByRole('button',{name:'Verify engine',exact:true}).click()
  await page.getByText('Engine integrity verified · game boot remains unverified.',{exact:true}).waitFor({timeout:45000})
  const r=await page.request.get(new URL('engine/licenses.html',url).href)
  if(!r.ok())throw Error('Engine credits missing under the repository path')
  if(await page.getByRole('link',{name:'Download website ZIP'}).count())throw Error('Standalone website points to a missing recursive export')
 })
 const denied=await open('memory-unavailable',`${url}?memory-check=1`,{hasTouch:true})
 await denied.page.context().clearCookies()
 // Fresh session; simulate a browser that cannot install the helper, not a failed network request.
 await denied.page.context().addInitScript(()=>{Object.defineProperty(navigator.serviceWorker,'register',{value:()=>Promise.reject(new Error('Browser blocked memory setup.'))})})
 await denied.goto(url)
 await check('Unsupported setup is honest, bounded and offers a manual retry',async()=>{
  await denied.page.getByRole('button',{name:'Setup',exact:true}).click()
  await denied.page.getByRole('button',{name:'Try memory setup again',exact:true}).waitFor()
  await denied.page.getByText(/Browser blocked memory setup\./).waitFor()
  const count=await denied.page.evaluate(()=>({isolated:crossOriginIsolated,marker:location.search}))
  if(count.isolated)throw Error('Refused helper was reported ready')
 })
 await page.getByRole('heading',{name:'A separate Safari page.',exact:true}).scrollIntoViewIfNeeded()
}
