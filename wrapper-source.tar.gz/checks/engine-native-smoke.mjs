import {readFile} from 'node:fs/promises'
import {pathToFileURL} from 'node:url'
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
try {
 const url=pathToFileURL(process.cwd()+'/public/engine/dolphin/cores/dolphin/dolphin-core-upstream.js')
 const {default:factory}=await import(url.href)
 const binary=await readFile('public/engine/dolphin/cores/dolphin/dolphin-core-upstream.wasm')
 assert.equal(createHash('sha256').update(binary).digest('hex'),'3b2ed6fe35ff1939e24bbe033edba34b9585f4f7b1f457f1e683ed8ddbd005d0')
 const m=await factory({noInitialRun:true,wasmBinary:binary,locateFile:p=>new URL(p,url).href,print:()=>{},printErr:()=>{}})
 for(const name of ['CoreInit','BootDisc','SetInputState','FrameBuffer','GetCoreStateName','SetCorePaused'])assert.equal(typeof m['_'+name],'function')
 assert.equal(m.ccall('SetVideoBackend','number',['string'],['Software Renderer']),1)
 assert.equal(m.ccall('CoreInit','number',[],[]),1)
 const state=m.ccall('GetCoreStateName','string',[],[])
 assert.equal(state,'Uninitialized')
 m.ccall('SetInputState',null,Array(10).fill('number'),[1|64|16384,0,128,128,128,0,255,255,0,1])
 m.ccall('SetInputState',null,Array(10).fill('number'),[0,128,128,128,128,0,0,0,0,2])
 assert.equal(m.ccall('BootDisc','number',['string'],['/missing-game.iso']),0)
 console.log(JSON.stringify({realWasmInstantiated:true,checksumVerified:true,CoreInit:1,state,heapBytes:m.HEAPU8.byteLength,gameCubeInputCalls:'accepted',missingDiscBoot:'rejected',gameplayVerified:false}))
 process.exit(0)
} catch(error){console.error(error);process.exit(1)}
