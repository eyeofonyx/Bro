export default async ({ open, check, url }) => {
 const session = await open('player', url, { hasTouch: true })
 const { page } = session
 const frame = page.frameLocator('iframe#app')
 const iso = frame.getByLabel('Choose Mario Kart Wii ISO')
 const makeDisc = (id = 'RMCE01', wii = true) => {
  const bytes = Buffer.alloc(0x50000)
  bytes.write(id, 0, 'ascii')
  if (wii) bytes.writeUInt32BE(0x5d1c9ea3, 0x18)
  bytes.write('Mario Kart Wii', 0x20, 'ascii')
  return bytes
 }
 await check('Invalid file has a helpful error', async () => {
  await iso.setInputFiles({ name: 'not-a-game.iso', mimeType:'application/octet-stream', buffer:makeDisc('BAD000',false) })
  await frame.getByRole('alert').filter({hasText:'No Wii disc header found'}).waitFor()
 })
 await check('Rejects other Wii games', async () => {
  await iso.setInputFiles({ name:'other-game.iso',mimeType:'application/octet-stream',buffer:makeDisc('SMNE01') })
  await frame.getByRole('alert').filter({hasText:'not a recognized Mario Kart Wii disc'}).waitFor()
 })
 await check('Recognizes Mario Kart Wii header without claiming gameplay', async () => {
  await iso.setInputFiles({ name:'header-test.iso',mimeType:'application/octet-stream',buffer:makeDisc() })
  await frame.getByText('HEADER RECOGNIZED',{exact:true}).waitFor()
  await frame.getByText('North America',{exact:true}).waitFor()
  if (!(await frame.getByRole('button',{name:'Disc too small to boot',exact:true}).isDisabled())) throw new Error('Gameplay must not be offered')
  await frame.getByText('This image is unusually small and may be incomplete.').waitFor()
 })
 await check('Remove clears the selected disc',async()=>{
  await frame.getByRole('button',{name:'Remove disc',exact:true}).click()
  await frame.getByRole('button',{name:'Choose ISO file',exact:true}).waitFor()
  if(await frame.getByText('HEADER RECOGNIZED',{exact:true}).count()) throw new Error('Disc still present')
 })
 await frame.getByRole('button',{name:'Touch controls',exact:true}).click()
 await check('Two simultaneous inputs are recognized and released',async()=>{
  const a = frame.getByRole('button',{name:'Test A button',exact:true})
  const r = frame.getByRole('button',{name:'Test R button',exact:true})
  const aBox = await a.boundingBox(); const rBox = await r.boundingBox()
  if(!aBox || !rBox)throw new Error('Controls are not visible')
  const cdp = await page.context().newCDPSession(page)
  const aPoint = {x:aBox.x+aBox.width/2,y:aBox.y+aBox.height/2,id:1}
  const rPoint = {x:rBox.x+rBox.width/2,y:rBox.y+rBox.height/2,id:2}
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[aPoint]})
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[aPoint,rPoint]})
  if(await a.getAttribute('aria-pressed')!=='true'||await r.getAttribute('aria-pressed')!=='true')throw new Error('Multi-touch state not held')
  await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[rPoint]})
  if(await a.getAttribute('aria-pressed')!=='true'||await r.getAttribute('aria-pressed')!=='false')throw new Error('Releasing one touch affected another input')
  await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]})
  if(await r.getAttribute('aria-pressed')!=='false')throw new Error('Stuck R button')
  await cdp.detach()
 })
 await check('Keyboard supports combined input',async()=>{
  await frame.getByRole('heading',{name:'Find your perfect grip.',exact:true}).click()
  await page.keyboard.down('x');await page.keyboard.down('e')
  if(await frame.getByRole('button',{name:'Test A button',exact:true}).getAttribute('aria-pressed')!=='true')throw new Error('A not pressed')
  if(await frame.getByRole('button',{name:'Test R button',exact:true}).getAttribute('aria-pressed')!=='true')throw new Error('R not pressed')
  await page.keyboard.up('x');await page.keyboard.up('e')
 })
 await check('Expanded tester opens and closes',async()=>{
  await frame.getByRole('button',{name:'Expand controller tester',exact:true}).click()
  await frame.getByRole('dialog',{name:'Expanded controller tester',exact:true}).waitFor()
  await frame.getByRole('button',{name:'Close tester',exact:true}).click()
  if(await frame.getByRole('dialog',{name:'Expanded controller tester',exact:true}).count())throw new Error('Tester did not close')
 })
 await check('Layout preferences survive reopening',async()=>{
  await frame.getByRole('button',{name:'Setup',exact:true}).click()
  const control=frame.getByRole('switch',{name:'Left-handed layout'})
  await control.check()
  await frame.getByLabel('Button size').press('End')
  await frame.getByLabel('Button opacity').press('Home')
  for(let i=0;i<6;i++)await frame.getByLabel('Button opacity').press('ArrowRight')
  await session.goto(url)
  await frame.getByRole('button',{name:'Setup',exact:true}).click()
  if(!(await frame.getByRole('switch',{name:'Left-handed layout'}).isChecked()))throw new Error('Handedness lost')
  if(await frame.getByLabel('Button size').inputValue()!=='115')throw new Error('Size lost')
  if(await frame.getByLabel('Button opacity').inputValue()!=='70')throw new Error('Opacity lost')
  await frame.getByRole('button',{name:'Reset layout',exact:true}).click()
  await frame.getByRole('button',{name:'Try layout',exact:true}).click()
 })
 return session
}
