import { createServer } from 'node:http'
import { readFile, stat } from 'node:fs/promises'
import { resolve, extname } from 'node:path'
const root = resolve('dist-pages')
const mime = { '.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.wasm':'application/wasm', '.json':'application/json', '.svg':'image/svg+xml', '.png':'image/png', '.txt':'text/plain', '.gz':'application/gzip', '.zip':'application/zip' }
// Mimics a GitHub project site: repository subpath and no COOP/COEP server headers.
const server = createServer(async (req, res) => {
 try {
  const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname)
  if (!pathname.startsWith('/kart/')) { res.writeHead(404).end(); return }
  const path = resolve(root, pathname.slice('/kart/'.length) || 'index.html')
  if (!path.startsWith(`${root}/`)) { res.writeHead(403).end(); return }
  const info = await stat(path)
  if (!info.isFile()) { res.writeHead(404).end(); return }
  res.writeHead(200, { 'Content-Type': mime[extname(path)] || 'application/octet-stream', 'Cache-Control': 'no-store' })
  res.end(await readFile(path))
 } catch { res.writeHead(404).end() }
})
server.listen(4173, '::', () => console.log('Pages fixture: http://localhost:4173/kart/ (no isolation headers)'))
