import regression from './wrapper.scenario.mjs'
export default async (args) => {
 let player
 await regression({...args,open:async(...parameters)=>{player=await args.open(...parameters);return player}})
 const {page}=player
 const {check}=args
 const frame=page.frameLocator('iframe#app')
 await check('Real Wii core compiles and verifies inside the actual app',async()=>{
  await frame.getByRole('button',{name:'Setup',exact:true}).click()
  await frame.getByRole('button',{name:'Verify engine',exact:true}).click()
  await frame.getByText('Engine integrity verified · game boot remains unverified.',{exact:true}).waitFor({timeout:45000})
  await frame.getByText('Playback is blocked in this browser view.',{exact:true}).waitFor()
 })
 await check('GameCube steering, accelerator, drift and trick map to real input bytes',async()=>{
  const result=await frame.locator('body').evaluate(async()=>{
   const engine=await import('/src/wii-engine.ts')
   return {combo:engine.padState(['A','R','←']),released:engine.padState([]),opposed:engine.padState(['←','→']),trick:engine.padState(['Trick']),blockers:engine.browserBlockers()}
  })
  if(result.combo.mask!==(1|64|16384)||result.combo.stickX!==0||result.combo.triggerRight!==255||result.combo.analogA!==255)throw new Error('GameCube input mapping is incorrect')
  if(result.released.mask!==0||result.released.stickX!==128||result.released.triggerRight!==0)throw new Error('Input release not neutral')
  if(result.opposed.stickX!==128||result.trick.mask!==256||result.trick.stickY!==128)throw new Error('Stick or trick mapping is incorrect')
  if(!result.blockers.some(item=>item.includes('cross-origin isolated')))throw new Error('Expected current embed isolation blocker to be explained')
 })
 await check('A launch attempt reports the real blocker instead of faking game video',async()=>{
  await frame.getByRole('button',{name:'Game loader',exact:true}).click()
  await frame.getByLabel('Choose Mario Kart Wii ISO').evaluate(input=>{
   const header=new Uint8Array(256);header.set(new TextEncoder().encode('RMCE01'));new DataView(header.buffer).setUint32(0x18,0x5d1c9ea3,false);header.set(new TextEncoder().encode('Mario Kart Wii'),0x20)
   const file=new File([header,new Uint8Array(16*1024*1024-256)],'synthetic-header-fixture.iso',{type:'application/octet-stream'})
   const transfer=new DataTransfer();transfer.items.add(file);input.files=transfer.files;input.dispatchEvent(new Event('change',{bubbles:true}))
  })
  await frame.getByRole('button',{name:'Check game startup',exact:true}).click()
  const player=frame.getByRole('dialog',{name:'Experimental Wii game player',exact:true})
  await player.getByText('The game could not start.',{exact:true}).waitFor()
  await player.getByRole('alert').filter({hasText:'cross-origin isolated'}).waitFor()
  if(!(await player.getByRole('button',{name:'Pause',exact:true}).isDisabled()))throw new Error('Pause should not be available without a running game')
  if(!(await player.getByRole('button',{name:'Sound off',exact:true}).isDisabled()))throw new Error('Sound should not be available without a running game')
  await player.getByRole('button',{name:'Close player'}).click()
  await frame.getByRole('button',{name:'Remove disc',exact:true}).click()
 })
 await check('Engine failure leaves the loader and controls usable',async()=>{
  await frame.getByRole('button',{name:'Touch controls',exact:true}).click()
  await frame.getByRole('button',{name:'Test A button',exact:true}).click()
  await frame.getByRole('status').filter({hasText:'A pressed'}).waitFor()
  await frame.getByRole('button',{name:'Setup',exact:true}).click()
  await frame.getByRole('heading',{name:'Dolphin is included.',exact:true}).scrollIntoViewIfNeeded()
 })
}
