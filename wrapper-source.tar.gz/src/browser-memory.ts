export const standaloneBuild = import.meta.env.VITE_STANDALONE === 'true'
export type HostingState = { kind: 'embedded' | 'disabled' | 'ready' | 'failed'; message: string }
let state: HostingState = { kind: 'disabled', message: 'The Safari memory helper runs only in the standalone website, never inside Maypop.' }
export function hostingState() { return state }
export function retryBrowserMemory() {
 const url = new URL(location.href)
 url.searchParams.delete('memory-check')
 location.replace(url.href)
}
// Run before the file picker is rendered: a necessary first-load refresh cannot lose an ISO selection.
// The URL marker bounds automatic refreshes even when browser storage is unavailable.
export async function prepareBrowserMemory(): Promise<boolean> {
 if (!standaloneBuild) return false
 if (window.top !== window) {
  state = { kind: 'embedded', message: 'Open this website directly in Safari, not inside another app’s embedded view. The memory helper will not run inside a frame.' }
  return false
 }
 if (globalThis.crossOriginIsolated && typeof SharedArrayBuffer !== 'undefined') {
  const url = new URL(location.href)
  if (url.searchParams.has('memory-check')) { url.searchParams.delete('memory-check'); history.replaceState(null, '', url.href) }
  state = { kind: 'ready', message: 'Shared browser memory is available on this page. This removes one blocker; it does not prove that the game works.' }
  return false
 }
 if (!globalThis.isSecureContext || !('serviceWorker' in navigator)) {
  state = { kind: 'failed', message: 'The memory helper requires a secure website and browser support. Open the published HTTPS address directly in Safari. Opening a downloaded page from Files will not work.' }
  return false
 }
 const current = new URL(location.href)
 if (current.searchParams.get('memory-check') === '1') {
  state = { kind: 'failed', message: 'Safari did not enable shared memory after the setup refresh. Automatic refreshes have stopped. This browser or host may not support the workaround. Trying again is optional; it does not guarantee compatibility.' }
  return false
 }
 const script = new URL(`${import.meta.env.BASE_URL}coi-serviceworker.js`, location.href)
 let timer: ReturnType<typeof setTimeout> | undefined
 let changed: (() => void) | undefined
 try {
  const setup = async () => {
   await navigator.serviceWorker.register(script.href, { scope: new URL('.', script).pathname, updateViaCache: 'none' })
   if (navigator.serviceWorker.controller?.scriptURL === script.href) return
   await new Promise<void>(resolve => {
    changed = () => { if (navigator.serviceWorker.controller?.scriptURL === script.href) resolve() }
    navigator.serviceWorker.addEventListener('controllerchange', changed)
    changed()
   })
  }
  await Promise.race([setup(), new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error('Browser memory setup took too long.')), 8000) })])
  current.searchParams.set('memory-check', '1')
  location.replace(current.href)
  return true
 } catch (error) {
  state = { kind: 'failed', message: `${error instanceof Error ? error.message : 'Browser memory setup failed.'} No further refresh will happen automatically. You can retry, or check that the complete website was uploaded and opened directly in Safari.` }
  return false
 } finally {
  clearTimeout(timer)
  if (changed) navigator.serviceWorker.removeEventListener('controllerchange', changed)
 }
}
