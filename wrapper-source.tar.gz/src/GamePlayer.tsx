import { useEffect, useRef, useState } from 'react'
import type { CSSProperties, PointerEvent } from 'react'
import { WiiSession } from './wii-engine'
import './Player.css'
export type Layout = {size:number;opacity:number;leftHand:boolean}
const bindings:Record<string,string> = {ArrowUp:'↑',ArrowDown:'↓',ArrowLeft:'←',ArrowRight:'→',KeyW:'↑',KeyS:'↓',KeyA:'←',KeyD:'→',KeyX:'A',KeyZ:'B',KeyV:'X',KeyB:'Y',KeyQ:'L',KeyE:'R',KeyC:'Z',KeyT:'Trick',Enter:'+'}
export function GamePlayer({ file, layout, onClose }: {file:File;layout:Layout;onClose:()=>void}) {
 const dialog=useRef<HTMLDialogElement>(null)
 const canvas=useRef<HTMLCanvasElement>(null)
 const session=useRef<WiiSession|null>(null)
 const sources=useRef(new Map<string,string>())
 const live=useRef(false)
 const pausedRef=useRef(false)
 const [held,setHeld]=useState<string[]>([])
 const [phase,setPhase]=useState<'booting'|'video'|'error'>('booting')
 const [message,setMessage]=useState('Preparing the real Wii engine…')
 const [paused,setPaused]=useState(false)
 const [sound,setSound]=useState(false)
 const [changing,setChanging]=useState(false)
 const [notice,setNotice]=useState('')
 function sync() { const keys=[...new Set(sources.current.values())];setHeld(keys);session.current?.setInput(keys) }
 function clear() { sources.current.clear();sync() }
 function input(source:string,label?:string) { if(label)sources.current.set(source,label);else sources.current.delete(source);sync() }
 useEffect(()=>{
  const inputs=sources.current
  dialog.current?.showModal()
  const engine=new WiiSession((state,text)=>{live.current=state==='video';setPhase(state);setMessage(text)},text=>{live.current=false;setPhase('error');setMessage(text)})
  session.current=engine
  if(canvas.current)void engine.start(file,canvas.current).catch(error=>{if(!engine.stopped){engine.stop();setPhase('error');setMessage(error instanceof Error?error.message:'The game could not start.')}})
  const down=(e:KeyboardEvent)=>{if(e.ctrlKey||e.metaKey||e.altKey||['INPUT','SELECT','TEXTAREA'].includes((e.target as HTMLElement)?.tagName))return;const label=bindings[e.code];if(label&&!(e.code==='Enter'&&(e.target as HTMLElement)?.tagName==='BUTTON')){e.preventDefault();input(`key:${e.code}`,label)}}
  const up=(e:KeyboardEvent)=>input(`key:${e.code}`)
  const hidden=()=>{
   clear()
   if(document.hidden&&live.current&&!pausedRef.current){void engine.pause(true).then(()=>{if(!engine.stopped){pausedRef.current=true;setPaused(true);setSound(false)}}).catch(()=>{})}
  }
  window.addEventListener('keydown',down);window.addEventListener('keyup',up);window.addEventListener('blur',clear);document.addEventListener('visibilitychange',hidden)
  return ()=>{window.removeEventListener('keydown',down);window.removeEventListener('keyup',up);window.removeEventListener('blur',clear);document.removeEventListener('visibilitychange',hidden);engine.stop();session.current=null;inputs.clear()}
 },[file])
 async function togglePause() {
  setChanging(true);setNotice('');clear()
  try {await session.current?.pause(!paused);pausedRef.current=!paused;setPaused(!paused);if(!paused)setSound(false)}catch(error){setNotice(error instanceof Error?error.message:'Unable to pause the game.')}finally{setChanging(false)}
 }
 async function toggleSound() {
  setNotice('')
  try { await session.current?.sound(!sound);setSound(!sound) } catch(error) {setNotice(error instanceof Error?error.message:'Sound is unavailable.');setSound(false)}
 }
 function pad(label:string,extra='') {
  const start=(e:PointerEvent<HTMLButtonElement>)=>{e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);input(`touch:${e.pointerId}`,label)}
  const end=(e:PointerEvent<HTMLButtonElement>)=>input(`touch:${e.pointerId}`)
  return <button key={label} className={`pad-button ${extra} ${held.includes(label)?'pressed':''}`} aria-label={`Game ${label} button`} aria-pressed={held.includes(label)} onPointerDown={start} onPointerUp={end} onPointerCancel={end} onLostPointerCapture={end} onKeyDown={e=>{if(e.key===' '||e.key==='Enter'){e.preventDefault();input(`focus:${label}`,label)}}} onKeyUp={e=>{if(e.key===' '||e.key==='Enter')input(`focus:${label}`)}} onBlur={()=>input(`focus:${label}`)}>{label==='Trick'?'↑ Trick':label}</button>
 }
 return <dialog ref={dialog} className="game-player" onCancel={event=>{event.preventDefault();onClose()}} aria-label="Experimental Wii game player">
  <header className="player-toolbar"><div><span className="player-kicker">DOLPHIN · EXPERIMENTAL</span><h2>Mario Kart Wii</h2></div><div className="player-actions"><button onClick={toggleSound} disabled={phase!=='video'||paused} aria-pressed={sound}>{sound?'Sound on':'Sound off'}</button><button onClick={togglePause} disabled={phase!=='video'||changing}>{changing?'Waiting…':paused?'Resume':'Pause'}</button><button onClick={()=>{clear();onClose()}}>Close player <span aria-hidden="true">×</span></button></div></header>
  <div className="player-content"><div className="player-screen"><canvas ref={canvas} width="640" height="480" aria-label="Live Dolphin game video"/>{phase!=='video'&&<div className={`player-state ${phase}`} role={phase==='error'?'alert':'status'}><span className={phase==='error'?'failure-symbol':'loading-ring'} aria-hidden="true">{phase==='error'?'!':''}</span><h3>{phase==='error'?'The game could not start.':'Starting the real Wii core…'}</h3><p>{message}</p>{phase==='error'&&<button className="primary" onClick={onClose}>Back to game loader</button>}<small>No simulated gameplay is shown.</small></div>}{paused&&phase==='video'&&<div className="pause-overlay"><strong>Paused</strong><p>Tap Resume when you're ready.</p></div>}</div>
  <div className={`live-controller ${layout.leftHand?'left-handed':''}`} style={{'--control-scale':layout.size/100,'--control-opacity':layout.opacity/100} as CSSProperties}><div className="gamepad"><div className="pad-left"><div className="shoulders">{pad('L')}<span>ITEM</span></div><div className="dpad">{pad('↑','up')}{pad('←','left')}<span className="dpad-center"/>{pad('→','right')}{pad('↓','down')}</div></div><div className="pad-middle">{pad('+','start-button')}{pad('Trick','trick-button')}</div><div className="pad-right"><div className="shoulders"><span>DRIFT</span>{pad('R')}</div><div className="action-buttons">{pad('Y','button-y')}{pad('X','button-x')}{pad('B','button-b')}{pad('A','button-a')}</div></div></div></div></div>
  <div className="player-footer" role="status">{notice || (phase==='video'?(paused?'Emulation paused.':message):'Real core · local disc · no uploads')}<span>GC CONTROLLER · {held.length?held.join(' + '):'TOUCH + KEYBOARD'}</span></div>
 </dialog>
}
