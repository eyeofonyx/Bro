import { hostingState, retryBrowserMemory, standaloneBuild } from './browser-memory'
import './HostingStatus.css'
export function HostingStatus() {
 const status = hostingState()
 return <section className="hosting-card" aria-labelledby="hosting-title">
  <div className="hosting-top"><div><span className="eyebrow">BROWSER ONLY · NO INSTALLATION</span><h2 id="hosting-title">A separate Safari page.</h2></div><span className="hosting-label">GITHUB PAGES</span></div>
  <p className="section-description">Try the player outside the embedded view. Your ISO stays on your iPad; the website does not include a game.</p>
  <div className={`hosting-result ${status.kind === 'ready' ? 'ready' : ''}`} role="status"><strong>{status.kind === 'ready' ? 'Shared memory ready' : standaloneBuild ? 'Browser memory setup' : 'This preview stays embedded'}</strong><p>{status.message}</p></div>
  {standaloneBuild ? <>
   {status.kind === 'failed' && <button className="primary hosting-retry" onClick={retryBrowserMemory}>Try memory setup again</button>}
   <p className="hosting-note">On first opening, this standalone website tries the memory helper and may refresh once, before you select your ISO. If setup fails, it stops and tells you why. Shared memory being ready is not a promise of Wii compatibility.</p>
  </> : <div className="hosting-columns"><div><a className="primary hosting-download" href={`${import.meta.env.BASE_URL}downloads/github-pages.zip`} download>Download website ZIP <span aria-hidden="true">↓</span></a><p className="hosting-note">A ready-to-host website, instructions and open-source credits. No games, selected files or personal settings are included.</p></div><ol className="hosting-steps"><li>Download and unzip the website in Files.</li><li>Upload the extracted website to your GitHub repository, keeping every folder in place. Uploading the ZIP alone will not work.</li><li>In GitHub, open Settings → Pages. Choose Deploy from a branch, your main branch, and the root folder. Save.</li><li>Open the published HTTPS link directly in Safari. Allow the first setup refresh, then open Setup to check shared memory.</li></ol></div>}
  <p className="hosting-warning"><strong>Still experimental on iPad.</strong> This is a hosting workaround, not a confirmed way to play Mario Kart Wii. Full game boot, racing and iPad performance remain unverified. GitHub may be easier to manage in Safari’s desktop website view; if your upload method cannot preserve folders, the ZIP cannot be deployed that way.</p>
 </section>
}
