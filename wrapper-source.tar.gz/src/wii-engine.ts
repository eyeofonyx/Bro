export type PadState = { mask: number; stickX: number; stickY: number; cStickX: number; cStickY: number; triggerLeft: number; triggerRight: number; analogA: number; analogB: number }
export type EngineReport = { verified: boolean; hash: string; exports: number; version: string }
export const ENGINE_VERSION = 'wasm-dolphin v0.1.1'
export const CORE_SHA256 = '3b2ed6fe35ff1939e24bbe033edba34b9585f4f7b1f457f1e683ed8ddbd005d0'
export function browserBlockers(): string[] {
 const reasons: string[] = []
 if (!globalThis.isSecureContext) reasons.push('Playback requires a secure browser connection.')
 if (typeof WebAssembly === 'undefined') reasons.push('This browser does not support WebAssembly.')
 else if (!WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,10,9,1,7,0,65,0,253,15,26,11]))) reasons.push('This browser does not support the WebAssembly SIMD instructions used by this engine.')
 if (!globalThis.crossOriginIsolated || typeof SharedArrayBuffer === 'undefined') reasons.push(window.top !== window ? 'This embedded browser view is not cross-origin isolated. The Wii engine needs shared memory; the surrounding host must enable it. A separate Safari website can try the memory helper; see Setup. This cannot be fixed with a touch-layout setting.' : 'This page is not cross-origin isolated, so shared browser memory is unavailable. Open Setup for the standalone memory helper result. A registered helper alone does not mean memory is ready.')
 if (typeof Worker === 'undefined') reasons.push('Browser workers are unavailable.')
 if (typeof HTMLCanvasElement === 'undefined' || !HTMLCanvasElement.prototype.transferControlToOffscreen) reasons.push('This browser cannot transfer the game display to a rendering worker.')
 return reasons
}
export function padState(labels: Iterable<string>): PadState {
 const keys = new Set(labels)
 const bits: Record<string,number> = { A:1, B:2, X:4, Y:8, '+':16, L:32, R:64, Z:128, 'Trick':256, '↑':1<<12, '↓':1<<13, '←':1<<14, '→':1<<15 }
 let mask = 0
 for (const key of keys) mask |= bits[key] || 0
 return { mask, stickX: keys.has('←') === keys.has('→') ? 128 : keys.has('←') ? 0 : 255, stickY:keys.has('↑') === keys.has('↓') ? 128 : keys.has('↑') ? 255 : 0, cStickX:128, cStickY:128, triggerLeft:keys.has('L') ? 255:0, triggerRight:keys.has('R')?255:0, analogA:keys.has('A')?255:0, analogB:keys.has('B')?255:0 }
}
export function verifyEngine(signal?: AbortSignal): Promise<EngineReport> {
 return new Promise((resolve,reject) => {
  const worker = new Worker(new URL('./engine-check.worker.ts',import.meta.url),{type:'module'})
  const timer = window.setTimeout(() => finish(new Error('Engine verification timed out. Try again when the connection is stable.')),60000)
  const abort = () => finish(new DOMException('Cancelled','AbortError'))
  function finish(error?: Error, report?: EngineReport) { window.clearTimeout(timer); signal?.removeEventListener('abort',abort); worker.terminate(); if(error) reject(error); else if(report) resolve(report) }
  worker.onmessage = e => e.data.error ? finish(new Error(e.data.error)) : finish(undefined,e.data)
  worker.onerror = () => finish(new Error('The engine verification worker could not start.'))
  if(signal?.aborted) return abort()
  signal?.addEventListener('abort',abort,{once:true})
  worker.postMessage({base: new URL(`${import.meta.env.BASE_URL}engine/dolphin/`,location.href).href,hash:CORE_SHA256})
 })
}
type BootResult = { coreBoot?: { accepted:boolean; skippedReason?:string }; coreStateName?:string; coreStatus?:string }
type Adapter = {
 loaded: boolean; worker:Worker|null; coreFrame:number; coreStateName:string; coreStatus:string; coreBoot?:{accepted:boolean}; presentedFrame:number
 mountGame(file:File):Promise<BootResult>; load():Promise<void>; setInputState(state:PadState):void; pollFrame():void; start():void
 mixAudio(frames?:number):Promise<unknown>; setAudioMuted(muted:boolean):void; request(type:string,payload?:object):Promise<BootResult>; applyFrame(result:BootResult):void; rejectAll(reason:string):void
}
type Audio = { setSource(source: (()=>Promise<unknown>)|null):void; setMuted(muted:boolean):Promise<boolean>; stopPump():void; context:AudioContext|null; workletNode:AudioWorkletNode|null }
export class WiiSession {
 adapter:Adapter|null = null
 audio:Audio|null = null
 stopped = false
 private timer = 0
 private initialFrame = 0
 private deadline = 0
 private frameObserved = false
 private statusPending = false
 private onState:(state:'booting'|'video',message:string)=>void
 private onError:(message:string)=>void
 constructor(onState:(state:'booting'|'video',message:string)=>void,onError:(message:string)=>void) { this.onState=onState;this.onError=onError }
 async start(file:File,canvas:HTMLCanvasElement) {
  const blockers=browserBlockers()
  if(blockers.length)throw new Error(blockers.join(' '))
  if(file.size<16*1024*1024)throw new Error('This image is too small to boot. A disc header alone is not a playable game.')
  const base = new URL(`${import.meta.env.BASE_URL}engine/dolphin/`,location.href)
  const adapterUrl=new URL('src/upstream-worker-adapter.js',base).href
  const audioUrl=new URL('src/audio.js',base).href
  const [adapterModule,audioModule] = await Promise.all([import(/* @vite-ignore */ adapterUrl),import(/* @vite-ignore */ audioUrl)])
  if(this.stopped)return
  this.adapter = new adapterModule.UpstreamWorkerAdapter({
   coreUrl:new URL('cores/dolphin/dolphin-core-upstream.js',base).href,
   expectedCoreSha256:CORE_SHA256,
   workerUrl:new URL('src/upstream-discio-worker.js',base).href,
   transferCanvas:()=>canvas.transferControlToOffscreen(),
   videoBackend:'Software Renderer', cpuThread:true, cpuCore:'cached', ppcWasmJit:true,ppcWasmJitWarmupFrames:700,
   fastSoftwareRaster:1,presenterBackend:'webgl',presentationPacing:'tick',presentationQueueSize:2,collectMetrics:false,noJitCache:true,
   onStatus:(message:string)=>{ if(!this.stopped && /abort|out of memory|failed to allocate/i.test(message)) this.fail(`The Wii engine stopped: ${message.slice(0,240)}`) }
  }) as Adapter
  this.audio = new audioModule.AudioController() as Audio
  this.onState('booting','Loading the real Dolphin core. It reserves about 1.5 GB of shared working memory.')
  const timeout=window.setTimeout(()=>this.fail('Engine startup timed out. The browser may not have enough available memory. Close other tabs and try again.'),90000)
  try {
   const result = await this.adapter.mountGame(file)
   if(this.stopped)return
   if(!result.coreBoot?.accepted)throw new Error(result.coreBoot?.skippedReason || result.coreStatus || 'Dolphin rejected this disc. The ISO may be incomplete or incompatible with this experimental build.')
   this.initialFrame=this.adapter.coreFrame
   this.audio.setSource(()=>this.adapter?.mixAudio(1024) || Promise.resolve({available:false}))
   this.adapter.setAudioMuted(true)
   this.onState('booting','Dolphin accepted the disc. Waiting for game video—not just the disc header.')
   this.deadline=performance.now()+90000
   this.adapter.worker?.addEventListener('error',()=>this.fail('The Wii engine worker stopped unexpectedly. The browser may have run out of memory.'))
   this.timer=window.setInterval(()=>{
    if(this.stopped||!this.adapter)return
    if(!this.frameObserved&&performance.now()>this.deadline){this.fail('No game video arrived after the disc was accepted. This title or browser may not be compatible with this engine build.');return}
    if(this.statusPending)return
    this.statusPending=true
    void this.adapter.request('playerStatus').then(result=>{
     if(this.stopped||!this.adapter)return
     this.adapter.applyFrame(result)
     if(result.coreStateName==='Running' && this.adapter.coreFrame>this.initialFrame+1 && !this.frameObserved) {
      this.frameObserved=true;this.onState('video','Game video detected. Mario Kart Wii playability and speed are not verified on this device.')
     }
     if(!this.frameObserved&&performance.now()>this.deadline)this.fail('No game video arrived after the disc was accepted. This title or browser may not be compatible with this engine build.')
     if(['Uninitialized','Stopping'].includes(result.coreStateName||'')&&this.frameObserved)this.fail('The Dolphin core stopped. Close the player and try again.')
    }).catch(error=>{if(!this.stopped)this.fail(error instanceof Error?error.message:'The engine stopped responding.')}).finally(()=>{this.statusPending=false})
   },500)
  } finally { window.clearTimeout(timeout) }
 }
 async pause(paused:boolean) {
  if(!this.adapter||this.stopped)return
  this.setInput([])
  const result=await this.adapter.request('playerPause',{paused})
  this.adapter.applyFrame(result)
  if(result.coreStateName!==(paused?'Paused':'Running'))throw new Error('The engine did not confirm the playback change. Try again.')
  if(paused)await this.audio?.setMuted(true)
 }
 async sound(enabled:boolean) {
  if(this.stopped||!this.adapter||!this.audio)return
  // Call setMuted from the user's click, before yielding, so iOS can resume audio.
  const result=this.audio.setMuted(!enabled)
  this.adapter.setAudioMuted(!enabled)
  if(enabled && !await result)throw new Error('Sound is unavailable in this browser session.')
 }
 setInput(labels:Iterable<string>) { if(!this.stopped)this.adapter?.setInputState(padState(labels)) }
 private fail(message:string) { if(this.stopped)return;this.stop();this.onError(message) }
 stop() {
  if(this.stopped)return
  this.setInput([]);this.stopped=true;window.clearInterval(this.timer)
  this.audio?.stopPump();this.audio?.workletNode?.disconnect();void this.audio?.context?.close().catch(()=>{})
  if(this.adapter){this.adapter.loaded=false;this.adapter.rejectAll('Player closed');this.adapter.worker?.terminate();this.adapter.worker=null}
 }
}
