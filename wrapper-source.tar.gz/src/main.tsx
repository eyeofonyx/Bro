import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { prepareBrowserMemory, standaloneBuild } from './browser-memory'
import './index.css'
import App from './App.tsx'

async function start() {
 // The standalone website does not depend on the Maypop host session.
 if (!standaloneBuild) await import('@basilica-digital/maypop-sdk')
 const notice = document.getElementById('boot-message')
 if (standaloneBuild && notice) notice.textContent = 'Preparing browser memory. This page may refresh once.'
 if (await prepareBrowserMemory()) return
 createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>)
}
void start()
