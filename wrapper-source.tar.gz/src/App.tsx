import { useEffect, useRef, useState } from 'react'
import type { CSSProperties, PointerEvent, ReactNode } from 'react'
import './App.css'
import { GamePlayer } from './GamePlayer'
import { EngineStatus } from './EngineStatus'
import { HostingStatus } from './HostingStatus'
import { browserBlockers } from './wii-engine'

type IconName = 'disc' | 'controller' | 'settings' | 'upload' | 'arrow' | 'check' | 'lock' | 'info' | 'close' | 'expand' | 'reset'
function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
 const paths: Record<IconName, ReactNode> = {
 disc: <><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.5"/><path d="m6 6 2 2m8 8 2 2"/></>,
 controller: <><path d="M7 7h10c3 0 4 3 5 9 .5 3-2 4-4 2l-3-3H9l-3 3c-2 2-4.5 1-4-2C3 10 4 7 7 7Z"/><path d="M6 10v5m-2.5-2.5h5"/><circle cx="16" cy="11" r=".7"/><circle cx="19" cy="14" r=".7"/></>,
 settings: <><path d="M4 7h16M4 17h16"/><circle cx="9" cy="7" r="3"/><circle cx="15" cy="17" r="3"/></>,
 upload: <><path d="M12 16V3m-5 5 5-5 5 5M4 15v5h16v-5"/></>,
 arrow: <><path d="M4 12h16m-6-6 6 6-6 6"/></>,
 check: <path d="m5 12 4 4L19 6"/>,
 lock: <><rect x="5" y="10" width="14" height="11" rx="3"/><path d="M8 10V6a4 4 0 0 1 8 0v4m-4 5v2"/></>,
 info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.5"/></>,
 close: <path d="m6 6 12 12M6 18 18 6"/>,
 expand: <path d="M4 9V4h5m6 0h5v5M4 15v5h5m6 0h5v-5"/>,
 reset: <><path d="M4 10a8 8 0 1 1 1 8M4 4v6h6"/></>,
 }
 return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>
}
function Wheel({ small = false }: { small?: boolean }) {
 return <svg className={small ? 'wheel small' : 'wheel'} viewBox="0 0 240 240" fill="none" aria-hidden="true"><circle cx="120" cy="120" r="92" stroke="#171e2b" strokeWidth="32"/><circle cx="120" cy="120" r="92" stroke="#c1c9d7" strokeWidth="22" strokeDasharray="125 170" transform="rotate(-52 120 120)"/><path d="m48 105 52 26 8 62h24l8-62 52-26-6-22-52 18h-28L54 83Z" fill="#dfe5ed"/><path d="m73 101 31 12m63-12-31 12" stroke="#a4afc2" strokeWidth="6" strokeLinecap="round"/><circle cx="120" cy="120" r="31" fill="#252e3f"/><circle cx="120" cy="120" r="23" stroke="#414d63"/><path d="m113 130 8-20h7l-8 20Z" fill="#ff794b"/><circle cx="166" cy="107" r="6" fill="#ff794b"/><circle cx="73" cy="106" r="5" fill="#353e4e"/></svg>
}
type Disc = { file: File; title: string; id: string; region: string; warning: boolean }
type Preferences = { size: number; opacity: number; leftHand: boolean }
const defaults: Preferences = { size: 100, opacity: 90, leftHand: false }
const keyMap: Record<string, string> = { ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→', x: 'A', z: 'B', q: 'L', e: 'R', Enter: '+', v: 'X', b: 'Y', c: 'Z', t:'Trick' }
function App() {
 const [tab, updateTab] = useState<'game'|'controls'|'setup'>('game')
 const [disc, setDisc] = useState<Disc | null>(null)
 const [playingFile,setPlayingFile] = useState<File|null>(null)
 const blockers = browserBlockers()
 const [error, setError] = useState('')
 const [busy, setBusy] = useState(false)
 const [drag, setDrag] = useState(false)
 const [expanded, updateExpanded] = useState(false)
 const [info, setInfo] = useState(false)
 const [prefs, setPrefs] = useState<Preferences>(() => { try { const p = JSON.parse(localStorage.getItem('mkw-touch-preferences') || '{}'); return { size: typeof p.size === 'number' ? Math.min(115,Math.max(85,p.size)) : 100, opacity: typeof p.opacity === 'number' ? Math.min(100,Math.max(40,p.opacity)) : 90, leftHand: p.leftHand === true } } catch { return defaults } })
 const [pressed, setPressed] = useState<string[]>([])
 const [lastInput, setLastInput] = useState('No buttons pressed')
 const sources = useRef(new Map<string, string>())
 const input = useRef<HTMLInputElement>(null)
 const version = useRef(0)
 const dialog = useRef<HTMLDialogElement>(null)
 const expandedDialog = useRef<HTMLDialogElement>(null)
 const helpTrigger = useRef<HTMLButtonElement>(null)
 function clear() { sources.current.clear(); setPressed([]) }
 function launch() { if(disc && disc.file.size>=16*1024*1024){clear();setPlayingFile(disc.file)} }
 function closePlayer() {clear();setPlayingFile(null)}
 function setTab(next: 'game'|'controls'|'setup') { clear(); updateTab(next) }
 function setExpanded(next: boolean) { clear(); updateExpanded(next) }
 function setButton(source: string, label?: string) {
  if (label) { sources.current.set(source, label); setLastInput(`${label} pressed`) } else sources.current.delete(source)
  setPressed([...new Set(sources.current.values())])
 }
 useEffect(() => { try { localStorage.setItem('mkw-touch-preferences', JSON.stringify(prefs)) } catch { /* Preferences are optional. */ } }, [prefs])
 useEffect(() => {
  const down = (e: KeyboardEvent) => { if (!['INPUT','BUTTON','SELECT','TEXTAREA'].includes((e.target as HTMLElement)?.tagName) && !e.ctrlKey && !e.metaKey && !e.altKey && !dialog.current?.open && !document.querySelector('dialog.game-player[open]')) { const label = keyMap[e.key] || keyMap[e.key.toLowerCase()]; if (label) { e.preventDefault(); setButton(`key:${e.code}`, label) } } }
  const up = (e: KeyboardEvent) => setButton(`key:${e.code}`)
  const visibility = () => { if (document.hidden) clear() }
  window.addEventListener('keydown',down); window.addEventListener('keyup',up); window.addEventListener('blur',clear); document.addEventListener('visibilitychange',visibility)
  return () => { window.removeEventListener('keydown',down); window.removeEventListener('keyup',up); window.removeEventListener('blur',clear); document.removeEventListener('visibilitychange',visibility) }
 }, [])
 useEffect(() => { if (expanded) expandedDialog.current?.showModal() }, [expanded])
 useEffect(() => { if (info) dialog.current?.showModal(); else dialog.current?.close() }, [info])
 useEffect(() => { if (!expanded) return; const escape = (e: KeyboardEvent) => { if(e.key === 'Escape') setExpanded(false) }; window.addEventListener('keydown', escape); return () => window.removeEventListener('keydown', escape) }, [expanded])
 async function load(file?: File) {
  if (!file) return
  const current = ++version.current
  setBusy(true); setError(''); setDisc(null)
  try {
   if (!file.name.toLowerCase().endsWith('.iso') || file.name.toLowerCase().endsWith('.nkit.iso')) throw new Error('Choose an uncompressed .iso file. ZIP, RVZ, WBFS and NKit images are not supported by this inspector.')
   if (file.size < 0x50000) throw new Error('This file is too small to be a complete Wii disc image. Choose your original ISO backup.')
   const buffer = await file.slice(0, 0x100).arrayBuffer()
   if (current !== version.current) return
   const view = new DataView(buffer)
   if (view.byteLength < 0x100 || view.getUint32(0x18, false) !== 0x5d1c9ea3) throw new Error('No Wii disc header found. Renaming a file to .iso does not make it a Wii disc image.')
   const decoder = new TextDecoder('ascii')
   const id = decoder.decode(new Uint8Array(buffer, 0, 6))
   if (!/^RMC[EPJK]01$/.test(id)) throw new Error(`This is a Wii image, but not a recognized Mario Kart Wii disc (${id.replace(/[^a-z0-9]/gi, '?')}). Choose a Mario Kart Wii ISO.`)
   const title = decoder.decode(new Uint8Array(buffer, 0x20, 0x60)).split('\0')[0].trim() || 'Mario Kart Wii'
   const regions: Record<string,string> = { E: 'North America', P: 'Europe / Australia', J: 'Japan', K: 'Korea' }
   setDisc({ file, title, id, region: regions[id[3]], warning: file.size < 1_000_000_000 })
  } catch (e) { if(current === version.current) setError(e instanceof Error ? e.message : 'This file could not be read. Try selecting it again.') }
  finally { if(current === version.current) setBusy(false) }
 }
 function pick() { input.current?.click() }
 function remove() { version.current++; setDisc(null); setError(''); setBusy(false); if(input.current) input.current.value = '' }
 function pad(label: string, extra = '') {
  const active = pressed.includes(label)
  const start = (e: PointerEvent<HTMLButtonElement>) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); setButton(`pointer:${e.pointerId}`,label) }
  const end = (e: PointerEvent<HTMLButtonElement>) => setButton(`pointer:${e.pointerId}`)
  return <button key={label} className={`pad-button ${extra} ${active ? 'pressed' : ''}`} aria-label={`Test ${label} button`} aria-pressed={active} onPointerDown={start} onPointerUp={end} onPointerCancel={end} onLostPointerCapture={end} onKeyDown={e => { if(e.key === ' ' || e.key === 'Enter') { e.preventDefault(); setButton(`focus:${label}`,label) } }} onKeyUp={e => { if(e.key === ' ' || e.key === 'Enter') setButton(`focus:${label}`) }} onBlur={() => setButton(`focus:${label}`)}>{label}</button>
 }
 const testStage = <div className={`controller-stage ${prefs.leftHand ? 'left-handed' : ''}`} style={{ '--control-scale': prefs.size / 100, '--control-opacity': prefs.opacity / 100 } as CSSProperties}>
  <div className="stage-grid"/><div className="stage-top"><span><i className="live-dot"/> INPUT TEST</span><span>CLASSIC LAYOUT</span></div>
  <div className="stage-center"><Wheel small/><strong>{pressed.length ? pressed.join(' + ') : 'Make yourself comfortable.'}</strong><span>{pressed.length ? 'Input detected · tester only' : 'Try the buttons. Find your grip.'}</span></div>
  <div className="gamepad"><div className="pad-left"><div className="shoulders">{pad('L')}<span>ITEM</span></div><div className="dpad">{pad('↑','up')}{pad('←','left')}<span className="dpad-center"/>{pad('→','right')}{pad('↓','down')}</div></div><div className="pad-middle">{pad('+','start-button')}<span>START</span></div><div className="pad-right"><div className="shoulders"><span>DRIFT</span>{pad('R')}</div><div className="action-buttons">{pad('Y','button-y')}{pad('X','button-x')}{pad('B','button-b')}{pad('A','button-a')}</div></div></div>
  <div className="stage-bottom"><span>TOUCH + KEYBOARD</span><span>No game is running</span></div>
 </div>
 return <div className="app-shell">
  <header className="workspace-bar"><div className="workspace-name"><span className="brand-mark"><Icon name="disc" size={20}/></span><strong>MKWii<span> / touch lab</span></strong></div><span className="local-badge"><i/> LOCAL ONLY</span></header>
  <main>
   <div className="intro"><div><div className="eyebrow">YOUR DISC. YOUR CONTROLS.</div><h1>A little closer to<br/>the starting line<span>.</span></h1><p>A home for your Wii ISO and a controller built for your fingertips.</p></div><div className="intro-tag"><span className="device-symbol">▯</span><div>Made for your hands<small>iPhone & iPad layouts</small></div></div></div>
   <div className="tab-bar"><nav aria-label="Workspace"><button className={tab==='game'?'active':''} onClick={() => setTab('game')}><Icon name="disc"/> Game loader</button><button className={tab==='controls'?'active':''} onClick={() => setTab('controls')}><Icon name="controller"/> Touch controls</button><button className={tab==='setup'?'active':''} onClick={() => setTab('setup')}><Icon name="settings"/> Setup</button></nav><span className="version">WRAPPER / 01</span></div>
   {tab === 'game' && <div className="main-grid"><section className="preview-section"><div className="section-heading"><h2>The driver's seat</h2><span className="mini-label">REAL WII CORE / EXPERIMENTAL</span></div>{testStage}<div className="preview-caption"><div><span className="caption-icon"><Icon name="controller"/></span><div><strong>Big buttons. Better grip.</strong><p>Multi-touch controls, made for the small screen.</p></div></div><button className="text-button" onClick={() => setTab('controls')}>Test controls <Icon name="arrow" size={17}/></button></div><div className="availability"><Icon name="info"/><div><strong>Real Dolphin engine. Experimental Wii playback.</strong><p>The player can boot a local disc and send GameCube controller input when browser requirements are met. Mario Kart Wii gameplay on iPhone or iPad has not been verified.</p><button className="inline-link" ref={helpTrigger} onClick={() => setInfo(true)}>About gameplay availability <span>↗</span></button></div></div></section>
   <aside className="load-panel"><div className="section-heading"><h2>Your game</h2><span className="step-number">01</span></div><div className="engine-summary"><Icon name="info" size={16}/><span>Dolphin Wii engine included.<br/><strong>{blockers.length?'Playback blocked in this browser view.':'Experimental boot available.'}</strong><button className="inline-link" onClick={()=>setTab('setup')}>Check playback requirements ↗</button></span></div><div className={`dropzone ${drag ? 'dragging':''} ${disc ? 'has-disc' : ''}`} onDragOver={e => { e.preventDefault(); setDrag(true) }} onDragLeave={() => setDrag(false)} onDrop={e => { e.preventDefault(); setDrag(false); void load(e.dataTransfer.files[0]) }}>
    {disc ? <><div className="disc-art"><Icon name="disc" size={55}/><span>Wii</span></div><span className="file-chip"><Icon name="check" size={13}/> HEADER RECOGNIZED</span><h3>Mario Kart Wii</h3><p className="file-name">{disc.file.name}</p><dl className="disc-details"><div><dt>Disc ID</dt><dd>{disc.id}</dd></div><div><dt>Region</dt><dd>{disc.region}</dd></div><div><dt>File size</dt><dd>{(disc.file.size / 1024 ** 3).toFixed(2)} GB</dd></div></dl>{disc.warning && <p className="small-warning">This image is unusually small and may be incomplete.</p>}<p className="inspection-note">Header inspection only, not a full integrity check.</p><button className={`primary ${disc.file.size<16*1024*1024?'muted':''}`} disabled={disc.file.size<16*1024*1024} onClick={launch}>{disc.file.size<16*1024*1024?'Disc too small to boot':blockers.length?'Check game startup':'Start experimental game'}</button><p className="boot-disclaimer">{blockers.length?'Shared browser memory is required. Open Setup for the specific blocker.':'Uses about 1.5 GB of memory. Game compatibility is unverified.'}</p><button className="text-button replace" onClick={pick}>Choose another ISO</button><button className="remove-button" onClick={remove}>Remove disc</button></> : <><div className="upload-icon"><Icon name="upload" size={29}/></div><h3>{busy ? 'Reading disc header…' : 'Bring your own disc.'}</h3><p>Select your Mario Kart Wii ISO.<br/>It stays right here on your device.</p><button className="primary" disabled={busy} onClick={pick}><Icon name="upload" size={17}/>{busy ? 'Inspecting…' : 'Choose ISO file'}</button><span className="drop-hint">or drop your file here</span><span className="format-tag">.ISO <span>UNCOMPRESSED</span></span></>}
   </div>{error && <div className="file-error" role="alert"><Icon name="info" size={18}/><p>{error}</p></div>}<div className="privacy"><Icon name="lock" size={17}/><p>No uploads. No game downloads.<br/>Use your own legally obtained backup.</p></div><div className="loader-note"><span>FILE INSPECTION</span><span className="status-pill">Available</span></div><div className="loader-note"><span>WII GAMEPLAY</span><span className="unavailable">{blockers.length?'Blocked here':'Experimental'}</span></div></aside></div>}
   {tab === 'controls' && <section className="controls-page"><div className="section-heading"><div><h2>Find your perfect grip.</h2><p className="section-description">Press and hold multiple buttons to check your layout. This is an input tester, not a game.</p></div><button className="icon-button" aria-label="Expand controller tester" onClick={() => setExpanded(true)}><Icon name="expand"/></button></div>{testStage}<div className="controls-under"><div className="input-status" role="status"><i className={pressed.length ? 'on':''}/><span>{pressed.length ? `${pressed.join(' + ')} held` : lastInput}</span></div><button className="text-button" onClick={() => setTab('setup')}>Adjust layout <Icon name="settings" size={18}/></button></div><div className="mapping-grid">{[['↑ ↓ ← →','Steering','Arrow keys'],['A','Accelerate','X key'],['B','Brake / reverse','Z key'],['R','Drift','E key'],['L','Use item','Q key'],['+','Start / pause','Enter']].map(([button,action,key]) => <div key={action}><span className="mapping-key">{button}</span><div><strong>{action}</strong><small>{key}</small></div></div>)}</div><p className="mapping-note">GameCube mapping for the real player: arrows drive the main stick; T triggers D-pad up for tricks. Q / E = L / R, C = Z, V / B = X / Y. This screen remains a safe input tester.</p></section>}
   {tab === 'setup' && <section className="setup-grid"><div className="settings-card"><div className="section-heading"><h2>Your touch layout</h2><Icon name="settings"/></div><p className="section-description">Make it yours. Preferences stay on this device.</p><label className="range-label" htmlFor="size">Button size <output>{prefs.size}%</output></label><input id="size" type="range" min="85" max="115" step="5" value={prefs.size} onChange={e => setPrefs({...prefs,size:Number(e.target.value)})}/><div className="range-ticks"><span>Compact</span><span>Large</span></div><label className="range-label" htmlFor="opacity">Button opacity <output>{prefs.opacity}%</output></label><input id="opacity" type="range" min="40" max="100" step="5" value={prefs.opacity} onChange={e => setPrefs({...prefs,opacity:Number(e.target.value)})}/><div className="range-ticks"><span>Subtle</span><span>Solid</span></div><label className="switch-row"><div><strong>Left-handed layout</strong><small>Swap steering and action buttons</small></div><input type="checkbox" role="switch" checked={prefs.leftHand} onChange={e=>setPrefs({...prefs,leftHand:e.target.checked})}/></label><div className="settings-actions"><button className="text-button" onClick={() => setPrefs(defaults)}><Icon name="reset" size={17}/> Reset layout</button><button className="primary" onClick={() => setTab('controls')}>Try layout <Icon name="arrow" size={17}/></button></div></div><div className="settings-card runtime"><div className="section-heading"><h2>Browser check</h2><span className="mini-label">LIVE CAPABILITIES</span></div><p className="section-description">These checks describe this browser, not game compatibility.</p>{[['WebAssembly',typeof WebAssembly !== 'undefined'],['WebGPU API','gpu' in navigator],['Shared memory',typeof SharedArrayBuffer !== 'undefined' && globalThis.crossOriginIsolated],['Touch input',navigator.maxTouchPoints > 0]].map(([label,yes]) => <div className="capability" key={String(label)}><span>{label}</span><span className={yes?'available':'not-available'}>{yes?'Detected':'Not detected'}{yes?<Icon name="check" size={15}/>:<span>—</span>}</span></div>)}<div className="engine-notice"><Icon name="info"/><div><strong>Dolphin engine included</strong><p>{blockers.length?'Shared-memory isolation is unavailable in this view. See the detailed playback check below.':'Browser prerequisites are present. Game boot and performance still need to be verified with your disc.'}</p></div></div></div><HostingStatus/><EngineStatus/></section>}
   <footer><span><i className="footer-dots">▦</i> A smaller screen. The same love for racing.</span><span>LOCAL FILES <i/> TOUCH FIRST <i/> NO ROMS INCLUDED</span></footer>
  </main>
  <input ref={input} type="file" accept=".iso" aria-label="Choose Mario Kart Wii ISO" className="hidden-file" onChange={e => { void load(e.target.files?.[0]); e.target.value = '' }}/>
  {expanded && <dialog ref={expandedDialog} className="expanded-tester" aria-label="Expanded controller tester" onCancel={() => setExpanded(false)}><button className="exit-expanded" autoFocus onClick={() => setExpanded(false)}><Icon name="close"/> Close tester</button>{testStage}<p>Input tester only · no game is running. Rotate your device for more room.</p></dialog>}
  <dialog ref={dialog} onCancel={() => setInfo(false)} onClose={() => { setInfo(false); helpTrigger.current?.focus() }}><div className="dialog-heading"><span className="eyebrow">A NOTE BEFORE YOU LOAD</span><button className="icon-button" aria-label="Close gameplay information" onClick={()=>setInfo(false)}><Icon name="close"/></button></div><h2>Real emulation, with limits.</h2><p>The real wasm-dolphin Wii core is included. On a compatible browser, Start experimental game mounts your ISO locally and asks Dolphin to boot it. The touch player sends GameCube controller inputs, not Wii Remote inputs.</p><p>Playback requires shared memory and a cross-origin-isolated browser view. The embedded version depends on its surrounding host. A separate Safari website can try the bundled memory helper; open Setup for the GitHub Pages download and instructions. A browser check or a recognized disc header does not prove Mario Kart Wii compatibility, and iPhone / iPad gameplay has not been verified.</p><p>Your selected file is kept only for this session. If you reload or close the app, choose it again.</p><button className="primary" onClick={()=>setInfo(false)}>Got it <Icon name="check" size={17}/></button></dialog>
 {playingFile && <GamePlayer file={playingFile} layout={prefs} onClose={closePlayer}/>}
 </div>
}
export default App
