/// <reference lib="webworker" />
export {}
self.onmessage = async (event:MessageEvent<{base:string;hash:string}>) => {
 try {
  const [response,glueResponse]=await Promise.all([fetch(new URL('cores/dolphin/dolphin-core-upstream.wasm',event.data.base)),fetch(new URL('cores/dolphin/dolphin-core-upstream.js',event.data.base))])
  if(!response.ok||!glueResponse.ok)throw new Error('The engine files could not be downloaded.')
  const glue=(await glueResponse.text()).replace(/\r\n/g,'\n')
  const glueDigest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(glue))
  const glueHash=Array.from(new Uint8Array(glueDigest),x=>x.toString(16).padStart(2,'0')).join('')
  if(glueHash!=='8eb5e8f8e335f57297ef41cd41bdec0443f095257e6ffac9933fabe8958307e8')throw new Error('The engine loader checksum did not match.')
  const bytes=await response.arrayBuffer()
  const digest=await crypto.subtle.digest('SHA-256',bytes)
  const hash=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('')
  if(hash!==event.data.hash)throw new Error('The engine checksum did not match. Playback was blocked to avoid running a damaged engine.')
  const module=await WebAssembly.compile(bytes)
  const exports=WebAssembly.Module.exports(module)
  for(const name of ['BootDisc','CoreInit','MountDisc','SetInputState','FrameBuffer','GetCoreStateName']) {
   const mapping=glue.match(new RegExp(`Module\\["_${name}"\\]=wasmExports\\["([^"]+)"\\]`))
   if(!mapping || !exports.some(item=>item.name===mapping[1]))throw new Error(`The real Wii engine is missing ${name}.`)
  }
  self.postMessage({verified:true,hash,exports:exports.length,version:'wasm-dolphin v0.1.1'})
 } catch(error) { self.postMessage({error:error instanceof Error?error.message:'The Wii engine could not be verified in this browser.'}) }
}
